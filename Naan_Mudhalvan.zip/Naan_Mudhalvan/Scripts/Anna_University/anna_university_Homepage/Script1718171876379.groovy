import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.annauniv.edu/')

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/a_VC Gallery'))

WebUI.switchToWindowTitle('Anna University, Chennai')

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/a_Home'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/b_Sustainability'))

WebUI.switchToWindowTitle('AU Sustainability')

WebUI.click(findTestObject('Object Repository/Anna_University/Page_AU Sustainability/button_'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_AU Sustainability/a_AU Home'))

WebUI.switchToWindowTitle('Anna University, Chennai')

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/img'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_QS_World_University_Rankings_2025.jpeg_d9525f/img'))

WebUI.doubleClick(findTestObject('Object Repository/Anna_University/Page_QS_World_University_Rankings_2025.jpeg_d9525f/img'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_QS_World_University_Rankings_2025.jpeg_d9525f/img'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/div_blink   animation 2s linear infinite co_387dcd'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/span'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Anna University, Chennai/a_Tamil Nadu MBA  MCA Admissions 2024-25'))

WebUI.switchToWindowTitle('TN MBA/MCA Online Counselling Home - MBAMCA')

WebUI.click(findTestObject('Object Repository/Anna_University/Page_TN MBAMCA Online Counselling Home - MBAMCA/div_User registration'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_TN MBAMCA Online Counselling Home - MBAMCA/button_Click here for New Registration'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Register - MBAMCA/button_Save'))

WebUI.click(findTestObject('Object Repository/Anna_University/Page_Register - MBAMCA/button_Reset'))

WebUI.closeBrowser()

