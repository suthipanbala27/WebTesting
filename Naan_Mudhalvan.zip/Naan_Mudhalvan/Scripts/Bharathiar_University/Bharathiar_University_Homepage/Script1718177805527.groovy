import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://b-u.ac.in/')

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/li_About BU'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/a_About BU'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_About BU  Bharathiar University/div_Enquiry Numbers_menu-bar'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_About BU  Bharathiar University/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/div_Enquiry Numbers_menu-bar'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/img'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Video Gallery  Bharathiar University/a_Online Payment'))

WebUI.switchToWindowTitle('BU-Online Payment Portal')

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Bharathiar University'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Frequently Asked Questions'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Home'))

WebUI.doubleClick(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Cancellation  Refund Policy'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Privacy Policy'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Home'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Bharathiar University'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_BU-Online Payment Portal/a_Contact Us'))

WebUI.openBrowser('')

WebUI.openBrowser('')

WebUI.navigateToUrl('https://b-u.ac.in/')

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Home  Bharathiar University/img'))

WebUI.switchToWindowTitle('Video Gallery | Bharathiar University')

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Video Gallery  Bharathiar University/a_Online Courses'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Online Programmes  Bharathiar University/ul_About BU                                _0d2a1a'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Online Programmes  Bharathiar University/span_Enquiry Numbers_three'))

WebUI.click(findTestObject('Object Repository/Bharathiar_University_Hompage/Page_Online Programmes  Bharathiar University/div_HomeAuthorities SenateStanding Committe_45e2c5'))

WebUI.closeBrowser()

