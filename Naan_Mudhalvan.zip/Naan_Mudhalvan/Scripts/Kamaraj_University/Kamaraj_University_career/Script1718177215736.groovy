import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://mkuniversity.ac.in/new/')

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/font_Links'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/a_Career'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/div_Notification                           _3ae547'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/a_Notification'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/strong_Upcoming Events'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/strong_Results'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_MADURAI KAMARAJ UNIVERSITY - OFFICIAL SITE/a_UG (CBCS) Revaluation result - April 2023'))

WebUI.switchToWindowTitle('Result | UG (CBCS)')

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/input_Enter your Register Number_search'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_Enter your Register Number             _ec33cf'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_Enter your Register Number'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_UG (CBCS) Revaluation Results April - 2_93ce3e'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/button_Refresh'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_Refresh'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_Refresh_ml-lg-auto col-lg-5 col-12'))

WebUI.click(findTestObject('Object Repository/Kamaraj_University/Kamaraj_University_career/Page_Result  UG (CBCS)/div_Semester Pattern  CourseSubject   UGB.A_8d8028'))

WebUI.closeBrowser()

