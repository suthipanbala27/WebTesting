<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_List of Recognised Guides              _dbcd33</name>
   <tag></tag>
   <elementGuidId>23f25f8a-6099-412c-a3b7-d6b83941af64</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(4)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;List of Recognised Guides University Departments / Affiliated Colleges Research &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2a253a5d-920c-4e02-aca6-d31fe82a2a03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

						 List of Recognised Guides 

                        

                         

                         

                         

                         

                         

                         

				        

						

						University Departments / Affiliated Colleges  Research Supervisor

                        

                        

                         

                         

                         

                         

				        

						

						University  / Affiliated Colleges  Research Centre's

                        

                        

                        

                         

                         

                         
                        

                        

                        

						

                       

                        

                        

                * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

                

                  

					   

             		

					</value>
      <webElementGuid>7a6f4577-bcd5-4e2c-903d-572456616cac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[4]</value>
      <webElementGuid>8677f4c9-ef4c-475b-93dc-fe39119bc945</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div[4]</value>
      <webElementGuid>794c81b0-884c-44ff-99b9-3c16305e9dd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[1]/following::div[1]</value>
      <webElementGuid>c7fa3228-de5e-4e2d-a76b-cc70ab5da37d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='* * * * * * * * * * * *'])[27]/following::div[1]</value>
      <webElementGuid>22c251be-8929-4f88-a78a-90dbe5dc72af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]</value>
      <webElementGuid>f7004bbb-a2c5-49cc-a9ed-2f5d8ef16c9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;

						 List of Recognised Guides 

                        

                         

                         

                         

                         

                         

                         

				        

						

						University Departments / Affiliated Colleges  Research Supervisor

                        

                        

                         

                         

                         

                         

				        

						

						University  / Affiliated Colleges  Research Centre&quot; , &quot;'&quot; , &quot;s

                        

                        

                        

                         

                         

                         
                        

                        

                        

						

                       

                        

                        

                * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

                

                  

					   

             		

					&quot;) or . = concat(&quot;

						 List of Recognised Guides 

                        

                         

                         

                         

                         

                         

                         

				        

						

						University Departments / Affiliated Colleges  Research Supervisor

                        

                        

                         

                         

                         

                         

				        

						

						University  / Affiliated Colleges  Research Centre&quot; , &quot;'&quot; , &quot;s

                        

                        

                        

                         

                         

                         
                        

                        

                        

						

                       

                        

                        

                * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

                

                  

					   

             		

					&quot;))]</value>
      <webElementGuid>90e1bf1a-cd8f-4d83-9e45-3a47a980d299</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
