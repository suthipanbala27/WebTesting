<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>center_News and Events</name>
   <tag></tag>
   <elementGuidId>5b52d287-b6b2-423f-9115-0f21aa44e17a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div[3]/div/div/table/tbody/tr/td/font/b/center</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>b > center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>font >> internal:has-text=&quot;News and Events&quot;i >> center</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>center</value>
      <webElementGuid>8f303dfc-6086-425e-a0cb-5998f7f912f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>News and Events

							 </value>
      <webElementGuid>6d1de4e5-e437-44b9-b9a2-e7cf0ea6191f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[3]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/font[1]/b[1]/center[1]</value>
      <webElementGuid>cd209484-a0aa-4a82-b462-7a0ce223246c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div[3]/div/div/table/tbody/tr/td/font/b/center</value>
      <webElementGuid>fbbb0043-9fea-4902-adc2-58460860fa50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research-Login'])[1]/following::center[1]</value>
      <webElementGuid>ebac8f25-7915-4866-bab0-1bed804ed0eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Regulations'])[1]/following::center[1]</value>
      <webElementGuid>76cd81e8-cbdd-4754-b54d-eec7de08c751</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='* * * * * * * * * * * *'])[1]/preceding::center[1]</value>
      <webElementGuid>cb928dc5-2207-4f13-b560-6da614828644</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//b/center</value>
      <webElementGuid>b1141f12-71e7-47ac-bea9-20c82aa58077</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//center[(text() = 'News and Events

							 ' or . = 'News and Events

							 ')]</value>
      <webElementGuid>51dccd40-7300-4352-8c82-42f673e477a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
