<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>center_Madurai Kamaraj University          _5092fb</name>
   <tag></tag>
   <elementGuidId>bd72a7bf-517d-415f-92a6-1b3666c4be67</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div[3]/div[2]/center</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(2) > center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Madurai Kamaraj University Welcome to Research Wing Previous year question paper&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>center</value>
      <webElementGuid>6bd2b7bc-5847-48ee-8f5a-9e808de571aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Madurai Kamaraj University

                        Welcome to Research Wing

                      

                   
					


		  
		  
		  

          
		  
          
   Previous year question papers of the aspirants of the Common Entrance Test - Admission to M.Phil/Ph.D - 2022

          

                    
                                    	 
   Viva-voce Examination Through Video Conference

          


                    
                    	  
    Online Ph.D Registration Form  

         



                 
   Research Section Management (RSM) 

          
		  

                 
   Enrollment of  Research Centres and its Supervisors   

         
		

                 
   Enrollment of Supervisors in Non - Research Centres 

         

         

                       
                        

                        

						
					   

                      

             

								

					</value>
      <webElementGuid>b2bfcb6b-ba76-406e-914b-3007dee09708</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[3]/div[2]/center[1]</value>
      <webElementGuid>05f16ea3-c973-4a2d-851c-146fd136da5a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div[3]/div[2]/center</value>
      <webElementGuid>54a3a142-410e-43e7-b516-97eb76eece8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[1]/following::center[1]</value>
      <webElementGuid>bf08e423-508a-49b8-b8bb-eee1fecc56cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='* * * * * * * * * * * *'])[31]/following::center[2]</value>
      <webElementGuid>610861de-17de-4d24-a897-073bae8707f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/center</value>
      <webElementGuid>0320e58c-4453-47f8-84bd-b15f823232a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//center[(text() = 'Madurai Kamaraj University

                        Welcome to Research Wing

                      

                   
					


		  
		  
		  

          
		  
          
   Previous year question papers of the aspirants of the Common Entrance Test - Admission to M.Phil/Ph.D - 2022

          

                    
                                    	 
   Viva-voce Examination Through Video Conference

          


                    
                    	  
    Online Ph.D Registration Form  

         



                 
   Research Section Management (RSM) 

          
		  

                 
   Enrollment of  Research Centres and its Supervisors   

         
		

                 
   Enrollment of Supervisors in Non - Research Centres 

         

         

                       
                        

                        

						
					   

                      

             

								

					' or . = 'Madurai Kamaraj University

                        Welcome to Research Wing

                      

                   
					


		  
		  
		  

          
		  
          
   Previous year question papers of the aspirants of the Common Entrance Test - Admission to M.Phil/Ph.D - 2022

          

                    
                                    	 
   Viva-voce Examination Through Video Conference

          


                    
                    	  
    Online Ph.D Registration Form  

         



                 
   Research Section Management (RSM) 

          
		  

                 
   Enrollment of  Research Centres and its Supervisors   

         
		

                 
   Enrollment of Supervisors in Non - Research Centres 

         

         

                       
                        

                        

						
					   

                      

             

								

					')]</value>
      <webElementGuid>7c1ae647-14c9-4e79-8cea-0528d19eeee1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
