<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Upcoming Events</name>
   <tag></tag>
   <elementGuidId>ff9e376e-eda6-4881-b9e6-28a347459c55</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='sidenav01']/a[3]/strong</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(3) > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Upcoming Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>1af71edf-6072-407b-908d-cc14c952680d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Upcoming Events</value>
      <webElementGuid>51da7403-ffa6-4c40-bf2f-a06590cbefbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidenav01&quot;)/a[3]/strong[1]</value>
      <webElementGuid>f3ca99af-8fbc-488d-9b4c-bc6bf9e9c9bf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='sidenav01']/a[3]/strong</value>
      <webElementGuid>e0dbbed0-8b27-4821-bbd9-6492615c4798</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Career'])[2]/following::strong[1]</value>
      <webElementGuid>d5a2efbe-fa4b-4c70-8bfd-9d4fe0da7831</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notification'])[1]/following::strong[2]</value>
      <webElementGuid>0b756b2c-ee39-420a-8e07-0626407a2464</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tenders'])[1]/preceding::strong[1]</value>
      <webElementGuid>87f02b58-c4c2-4dd6-adfc-e0864e39469f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission'])[1]/preceding::strong[2]</value>
      <webElementGuid>b9f969c3-0364-4dc0-bf4a-7c7bd26dea06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Upcoming Events']/parent::*</value>
      <webElementGuid>6b398a51-7950-4b4a-adb8-8be24249a64b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[3]/strong</value>
      <webElementGuid>382df12c-1020-4396-b9ca-f226549daec7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Upcoming Events' or . = 'Upcoming Events')]</value>
      <webElementGuid>0e382a19-dd66-460e-98b0-50c2c6bfdcef</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
