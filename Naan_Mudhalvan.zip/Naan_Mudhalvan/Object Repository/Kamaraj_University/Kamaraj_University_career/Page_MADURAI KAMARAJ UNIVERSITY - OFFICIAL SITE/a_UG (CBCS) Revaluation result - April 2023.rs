<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_UG (CBCS) Revaluation result - April 2023</name>
   <tag></tag>
   <elementGuidId>dc09b4d8-8ead-400e-aaf0-79510e08568b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='tridev']/div/font/div/ul/li/div[2]/strong/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>strong > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;UG (CBCS) Revaluation result - April 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>29994a4e-e3cb-47c8-ac26-677623b70e65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://result.mkuniversity.ac.in/ug_rev_3/</value>
      <webElementGuid>0744a15c-22ef-435e-9bbb-fefe809f0fe3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_new</value>
      <webElementGuid>1d3e0d47-3fa4-4436-a083-3f40f5a17fc7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG (CBCS) Revaluation result - April 2023</value>
      <webElementGuid>f2984273-766a-4ec9-9f2e-dc0d0ccb9290</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tridev&quot;)/div[@class=&quot;col-md-12&quot;]/font[1]/div[1]/ul[@class=&quot;media-list&quot;]/li[@class=&quot;media margin-bottom-20&quot;]/div[@class=&quot;media-body&quot;]/strong[1]/a[1]</value>
      <webElementGuid>ecccb93c-9c9f-4c3e-b4d3-9800fefc5acd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='tridev']/div/font/div/ul/li/div[2]/strong/a</value>
      <webElementGuid>90a65ab3-4631-408d-8536-c060540b2c8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'UG (CBCS) Revaluation result - April 2023')]</value>
      <webElementGuid>ab3d0bd2-c739-40d5-9c82-9f7a4962a849</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Results'])[3]/following::a[1]</value>
      <webElementGuid>0918b377-3b26-4200-b8c0-276104daa3e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Results'])[2]/following::a[1]</value>
      <webElementGuid>6eb504b9-104e-43b5-b303-25cfc7526ea7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG November -2023 Semester Examinations Private Application'])[1]/preceding::a[1]</value>
      <webElementGuid>667db83b-3a8c-4d6a-8a2c-2d0711306a04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG November -2023 Semester Examinations Private Application'])[1]/preceding::a[2]</value>
      <webElementGuid>3142ec42-17ee-41ce-89c7-e8234364d7c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG (CBCS) Revaluation result - April 2023']/parent::*</value>
      <webElementGuid>db284227-b8e5-485c-bd19-7452f1e5664f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://result.mkuniversity.ac.in/ug_rev_3/')]</value>
      <webElementGuid>a51b6071-537c-49ae-9348-68d1ca7af839</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//strong/a</value>
      <webElementGuid>45a2e216-0977-42e2-9abd-aa829561aa3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://result.mkuniversity.ac.in/ug_rev_3/' and (text() = 'UG (CBCS) Revaluation result - April 2023' or . = 'UG (CBCS) Revaluation result - April 2023')]</value>
      <webElementGuid>f9cce77e-1339-4784-bcef-8fc4f7484b30</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
