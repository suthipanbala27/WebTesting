<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Notification                           _3ae547</name>
   <tag></tag>
   <elementGuidId>ae2c2069-1cae-4150-b9e4-1f410caf6b2b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navbar-collapse.collapse.sidebar-navbar-collapse</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=navigation >> div >> internal:has-text=&quot;Notification Career Upcoming Events Tenders Admission Results&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>13d67c3c-700c-4fef-8a6f-d56d840bfe1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar-collapse collapse sidebar-navbar-collapse</value>
      <webElementGuid>929bb18b-f8a5-4e9c-b0a4-e0f2834cc047</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
       
       
       
        
      
                                                  
                                                 Notification 
                                              
                                                   
                                                  Career
                                                  
                                            
                                                  
                                                 Upcoming Events
                                               
                                                   Tenders
                                                 
                                                Admission
                                                
                                                 Results
                                               
                                              
                                                  
                                               
                                                   
                                              
                                               
                                                  
                                               
                                               
                                                
                                            
                                        
                                
      </value>
      <webElementGuid>e697eafe-514a-4eae-90f8-092df71ce887</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container&quot;]/div[@class=&quot;sidenav&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;panel panel-default sidebar-menu&quot;]/font[1]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;navbar navbar-default&quot;]/div[@class=&quot;navbar-collapse collapse sidebar-navbar-collapse&quot;]</value>
      <webElementGuid>95845895-ab29-4e1f-9f71-c5fdab8debd7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/following::div[1]</value>
      <webElementGuid>80775afb-2e32-4a80-807f-e93460bdfaf3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[2]/following::div[1]</value>
      <webElementGuid>ae284b65-c316-4879-a3eb-a9ac8c2cbfe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//font/div/div/div[2]</value>
      <webElementGuid>ddd438b9-5bdd-4a36-b0ed-200caa3eae36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
      
       
       
       
        
      
                                                  
                                                 Notification 
                                              
                                                   
                                                  Career
                                                  
                                            
                                                  
                                                 Upcoming Events
                                               
                                                   Tenders
                                                 
                                                Admission
                                                
                                                 Results
                                               
                                              
                                                  
                                               
                                                   
                                              
                                               
                                                  
                                               
                                               
                                                
                                            
                                        
                                
      ' or . = '
      
       
       
       
        
      
                                                  
                                                 Notification 
                                              
                                                   
                                                  Career
                                                  
                                            
                                                  
                                                 Upcoming Events
                                               
                                                   Tenders
                                                 
                                                Admission
                                                
                                                 Results
                                               
                                              
                                                  
                                               
                                                   
                                              
                                               
                                                  
                                               
                                               
                                                
                                            
                                        
                                
      ')]</value>
      <webElementGuid>38e14233-8503-4a15-bb85-3c45afd9cb57</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
