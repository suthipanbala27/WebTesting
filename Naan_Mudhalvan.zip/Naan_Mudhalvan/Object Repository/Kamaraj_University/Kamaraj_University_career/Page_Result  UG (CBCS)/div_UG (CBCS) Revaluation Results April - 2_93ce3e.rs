<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_UG (CBCS) Revaluation Results April - 2_93ce3e</name>
   <tag></tag>
   <elementGuidId>a6d659ff-f57e-413b-9c63-f496741ee697</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.gwrapper > div.container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;UG (CBCS) Revaluation Results April - 2023 Semester Pattern: Course Subject UG B&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cbe00d30-d440-4d91-8ac2-d01f2bf3fa2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>9748df25-dbca-4540-a3ce-9b7b2ea49ec5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

UG (CBCS) Revaluation Results April - 2023

     


      
        
          
          
           

            
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            
          

          
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          

        
      
    
 



</value>
      <webElementGuid>ee8d693f-4e05-41cb-9948-8e00cd29dba2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;gwrapper&quot;]/div[@class=&quot;container&quot;]</value>
      <webElementGuid>008ee6df-5e8e-4a16-8213-e6e34889b318</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>a21fcde9-f8ac-4037-8705-455a68683d7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

UG (CBCS) Revaluation Results April - 2023

     


      
        
          
          
           

            
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            
          

          
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          

        
      
    
 



' or . = '

UG (CBCS) Revaluation Results April - 2023

     


      
        
          
          
           

            
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            
          

          
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          

        
      
    
 



')]</value>
      <webElementGuid>61f619ae-5217-4d71-922a-23c244013cc3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
