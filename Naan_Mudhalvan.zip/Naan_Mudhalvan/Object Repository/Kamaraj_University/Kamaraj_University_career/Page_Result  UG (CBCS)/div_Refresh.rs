<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Refresh</name>
   <tag></tag>
   <elementGuidId>070e6746-72c4-42bd-89c3-fcca23abdf63</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='contact']/div/div/div[2]/div/form/div/div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>form[name=&quot;form&quot;] div >> internal:has-text=&quot;Refresh&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b9fe007d-82d0-4150-8c34-275d8b20b2b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-lg-6 col-12</value>
      <webElementGuid>34e81d77-5aac-42a2-a6bb-edeafe913d63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				 
				Refresh
				</value>
      <webElementGuid>3d9e4f77-9fec-480a-a286-9cbc5910d691</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-4 col-12&quot;]/div[@class=&quot;contact-form&quot;]/form[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-6 col-12&quot;]</value>
      <webElementGuid>eae6bab7-b852-4fad-b714-31532613efac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='contact']/div/div/div[2]/div/form/div/div[4]</value>
      <webElementGuid>720bdb2b-3502-4c34-b445-e80885f24fb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter Captcha:'])[1]/following::div[2]</value>
      <webElementGuid>d75c1d02-4292-4e96-b8b0-a64c5ad4fd26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your Register Number:'])[1]/following::div[3]</value>
      <webElementGuid>680d9323-2d97-4ad6-8d15-7ed77db96220</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]</value>
      <webElementGuid>198c5cc1-1b93-49bf-81d4-b5980f27037a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				 
				Refresh
				' or . = '
				 
				Refresh
				')]</value>
      <webElementGuid>ab6839bd-3381-486a-bf7c-661f52f25312</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
