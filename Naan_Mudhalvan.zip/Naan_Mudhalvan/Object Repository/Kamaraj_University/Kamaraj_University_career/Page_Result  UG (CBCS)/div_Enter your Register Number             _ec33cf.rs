<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Enter your Register Number             _ec33cf</name>
   <tag></tag>
   <elementGuidId>845b5265-e540-4cb5-8467-91181847867a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='contact']/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-lg-4.col-12</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#contact div >> internal:has-text=&quot;Enter your Register Number: Enter Captcha: Refresh Submit&quot;i >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b47469ca-2fa1-4bce-b848-f8de91f58c24</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-lg-4 col-12</value>
      <webElementGuid>bac0b91a-3479-462c-912b-ca4a2829d3ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          </value>
      <webElementGuid>d30e6f11-ae42-4378-b77d-542de61a836f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-4 col-12&quot;]</value>
      <webElementGuid>eec76250-3b50-40b6-b110-16e40ae9df01</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='contact']/div/div/div[2]</value>
      <webElementGuid>4ed9de55-0331-4531-9e1b-1225174c10b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG'])[1]/following::div[1]</value>
      <webElementGuid>32937d6f-4d57-489a-abcc-8d9d6702ee45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]</value>
      <webElementGuid>51348418-064f-44a9-af49-241aed40b219</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          ' or . = '
            
              

              
                
                  
                  Enter your Register Number:
                  

                  
                 Enter Captcha: 

                  
				
                 
					

                  
                 
				 
				Refresh
				


                  
                    
                  
                
              
            
          ')]</value>
      <webElementGuid>49219113-fd66-4104-a626-9c0f7f56a559</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
