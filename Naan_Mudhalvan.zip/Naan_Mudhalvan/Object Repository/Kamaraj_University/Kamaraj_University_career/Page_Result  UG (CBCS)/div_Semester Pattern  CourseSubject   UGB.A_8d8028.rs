<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Semester Pattern  CourseSubject   UGB.A_8d8028</name>
   <tag></tag>
   <elementGuidId>b3fafb7b-c605-4ab8-9495-5eaacaf2757a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='contact']/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.contact-info.d-flex.justify-content-between.align-items-center.py-4.px-lg-5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#contact div >> internal:has-text=&quot;Semester Pattern: Course Subject UG B.A / B.B.A / B.COM / B.SC&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e803592a-5a3b-4e62-be6e-2e989b14e0b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>contact-info d-flex justify-content-between align-items-center py-4 px-lg-5</value>
      <webElementGuid>05d64a30-a057-48c5-a290-304bef078537</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            </value>
      <webElementGuid>00843276-98a3-4adb-a1f2-7d6556d88d4a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-8 mr-lg-8 col-12&quot;]/div[@class=&quot;contact-info d-flex justify-content-between align-items-center py-4 px-lg-5&quot;]</value>
      <webElementGuid>370524a7-c3b2-44eb-b3b7-e6c51d443eff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='contact']/div/div/div/div</value>
      <webElementGuid>e436f11e-a1e9-4543-9168-0cd96cf9c21c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG (CBCS) Revaluation Results April - 2023'])[1]/following::div[4]</value>
      <webElementGuid>fd47a1f8-be0e-47ed-b5d5-4ed886746f71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div</value>
      <webElementGuid>7947e6f5-cc51-4fb8-93c0-fb757a119fb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            ' or . = '
                
                   Semester Pattern:
		
			  
				Course
				Subject
			   
				UG
				B.A / B.B.A / B.COM  / B.SC
			   
   
		
                

                
                     
                     
                     
                
            ')]</value>
      <webElementGuid>be2a2d61-de40-4822-a8ed-c79185db4994</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
