<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_</name>
   <tag></tag>
   <elementGuidId>9375995f-7035-41a2-ae95-5daa47d815e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Students Counseling Cell'])[1]/following::i[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li > a > strong > i.fa.fa-search</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>f9aad460-83bd-48ce-be12-1913ebd7ca69</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-search</value>
      <webElementGuid>3bbbb918-41e0-4a63-81f7-f525bb0be306</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>    </value>
      <webElementGuid>9dc1018e-55f8-48ed-8027-2555186de41a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;navbar navbar-fixed-top navbar-default&quot;]/div[@class=&quot;navbar&quot;]/div[@class=&quot;collapse navbar-collapse js-navbar-collapse&quot;]/ul[@class=&quot;nav navbar-nav navbar-right&quot;]/li[1]/a[1]/strong[1]/i[@class=&quot;fa fa-search&quot;]</value>
      <webElementGuid>9825027b-53e3-48a4-888c-1545aa67ba1a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Students Counseling Cell'])[1]/following::i[1]</value>
      <webElementGuid>6f061dd6-b707-486f-901a-1db95ef2b8c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scheduled Castes and Scheduled Tribes Cell (SC/ST Cell)'])[1]/following::i[1]</value>
      <webElementGuid>763f8d1f-69a9-4014-b0a9-7fb2c06a3f5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IMPORTANT NEWS'])[1]/preceding::i[1]</value>
      <webElementGuid>212907b8-56f8-4f92-85e7-b2281680f30f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='QS Asia University Rankings 2024'])[1]/preceding::i[1]</value>
      <webElementGuid>04464bff-4259-4a04-9b55-08d0fbaa033b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a/strong/i</value>
      <webElementGuid>640cf179-7520-42a4-b6bf-70491876d5ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//i[(text() = '    ' or . = '    ')]</value>
      <webElementGuid>5ada383f-b4ff-40a7-b73e-a80526c0aa63</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
