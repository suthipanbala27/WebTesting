<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_HomeAuthorities SenateStanding Committe_45e2c5</name>
   <tag></tag>
   <elementGuidId>dbd7bb5a-f46a-4847-b07d-c4e9418c1f13</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='block-mainnavigation-8']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#block-mainnavigation-8</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#block-mainnavigation-8</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b328c99b-35ae-45a3-9011-5b28c7b212aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>block-mainnavigation-8</value>
      <webElementGuid>2a813b8c-cc94-4384-ac22-5781d5e16319</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menu-navigation block block-superfish block-superfishmain no-title</value>
      <webElementGuid>bd0afc88-8be9-4e84-8a33-e6322022e4b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  
    
      
      






  





HomeAuthorities »SenateStanding CommitteeSyndicateFacultiesPlanning BoardAdministrators »ChancellorPro-ChancellorVice-ChancellorRegistrarController of ExaminationsDeansFinance OfficerOther OfficesAcademics »Schools / DepartmentsPG Extension &amp; Research CentreAffiliated CollegesResearch InstitutesSchool of Distance EducationCommunity CollegesUGC-MMTTCAnna IAS AcademyResearch »Admission &amp; RegulationsDistinctivenessProjectsPublicationsUGC ProjectsPh.D. EnrollmentPh.D. Thesis StatusUniversity JournalRUSAPURSECentres »DIA-CoE BUIncubation and Technology Transfer CenterCRTDCentre for International AffairsCentre for Research &amp; EvaluationCUICCentral Instrumentation CentreIncubation Centreபாரதி உயராய்வு மையம்Students »ProgrammesAdmissionScholarships and FellowshipsChoice Based Credit SystemSyllabusExaminationsResultsPlacementsInternational Students SupportAlumniAcademic CalendarSchool of Distance EducationSWAYAMNADNSSStudents ClubYRCCells »IQACIPR CellSC/ST CellWomen CellAnti-Ragging CellUniversity CM CellStatistics CellInternal Complaints CommitteeEqual Opportunity CellMinorities CellFacilities »ICT Swimming PoolTransport FacilityOnline PortalLibraryAuditoriums and HallsCentre for Internet &amp; Website ServicesHostelsUniversity HospitalFitness CentreGuest HousesAmenitiesLinks »Certificate VerificationEmployee LoginHerbal GardenPensioner LoginSkill DevelopmentAcademic CalendarProspectusAnnual ReportsAudit ReportsEvents RecruitmentRTIPhoto GalleryFinancial DataFormsEnquiry Numbers








    
  </value>
      <webElementGuid>2e57e370-c6b6-460c-b334-0130e45a3010</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-mainnavigation-8&quot;)</value>
      <webElementGuid>3fcf08fc-8b70-4b5c-8ae0-2c4626726b28</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='block-mainnavigation-8']</value>
      <webElementGuid>b0ac9508-a32a-4836-8238-5588164d93e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header-one']/div/div/div/div[3]/div/div/div/div/div[3]/div/div</value>
      <webElementGuid>c1774d7e-8ab5-4d8c-9081-d11f62b62c1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/following::div[24]</value>
      <webElementGuid>e7199ea6-6bcb-499d-ae25-190db442a055</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[1]/following::div[27]</value>
      <webElementGuid>7ddb60bb-9ead-44b8-b15e-b404e9304379</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div[3]/div/div</value>
      <webElementGuid>75591f90-266e-4be6-9100-cd3da00ab9a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'block-mainnavigation-8' and (text() = '
  
    
      
      






  





HomeAuthorities »SenateStanding CommitteeSyndicateFacultiesPlanning BoardAdministrators »ChancellorPro-ChancellorVice-ChancellorRegistrarController of ExaminationsDeansFinance OfficerOther OfficesAcademics »Schools / DepartmentsPG Extension &amp; Research CentreAffiliated CollegesResearch InstitutesSchool of Distance EducationCommunity CollegesUGC-MMTTCAnna IAS AcademyResearch »Admission &amp; RegulationsDistinctivenessProjectsPublicationsUGC ProjectsPh.D. EnrollmentPh.D. Thesis StatusUniversity JournalRUSAPURSECentres »DIA-CoE BUIncubation and Technology Transfer CenterCRTDCentre for International AffairsCentre for Research &amp; EvaluationCUICCentral Instrumentation CentreIncubation Centreபாரதி உயராய்வு மையம்Students »ProgrammesAdmissionScholarships and FellowshipsChoice Based Credit SystemSyllabusExaminationsResultsPlacementsInternational Students SupportAlumniAcademic CalendarSchool of Distance EducationSWAYAMNADNSSStudents ClubYRCCells »IQACIPR CellSC/ST CellWomen CellAnti-Ragging CellUniversity CM CellStatistics CellInternal Complaints CommitteeEqual Opportunity CellMinorities CellFacilities »ICT Swimming PoolTransport FacilityOnline PortalLibraryAuditoriums and HallsCentre for Internet &amp; Website ServicesHostelsUniversity HospitalFitness CentreGuest HousesAmenitiesLinks »Certificate VerificationEmployee LoginHerbal GardenPensioner LoginSkill DevelopmentAcademic CalendarProspectusAnnual ReportsAudit ReportsEvents RecruitmentRTIPhoto GalleryFinancial DataFormsEnquiry Numbers








    
  ' or . = '
  
    
      
      






  





HomeAuthorities »SenateStanding CommitteeSyndicateFacultiesPlanning BoardAdministrators »ChancellorPro-ChancellorVice-ChancellorRegistrarController of ExaminationsDeansFinance OfficerOther OfficesAcademics »Schools / DepartmentsPG Extension &amp; Research CentreAffiliated CollegesResearch InstitutesSchool of Distance EducationCommunity CollegesUGC-MMTTCAnna IAS AcademyResearch »Admission &amp; RegulationsDistinctivenessProjectsPublicationsUGC ProjectsPh.D. EnrollmentPh.D. Thesis StatusUniversity JournalRUSAPURSECentres »DIA-CoE BUIncubation and Technology Transfer CenterCRTDCentre for International AffairsCentre for Research &amp; EvaluationCUICCentral Instrumentation CentreIncubation Centreபாரதி உயராய்வு மையம்Students »ProgrammesAdmissionScholarships and FellowshipsChoice Based Credit SystemSyllabusExaminationsResultsPlacementsInternational Students SupportAlumniAcademic CalendarSchool of Distance EducationSWAYAMNADNSSStudents ClubYRCCells »IQACIPR CellSC/ST CellWomen CellAnti-Ragging CellUniversity CM CellStatistics CellInternal Complaints CommitteeEqual Opportunity CellMinorities CellFacilities »ICT Swimming PoolTransport FacilityOnline PortalLibraryAuditoriums and HallsCentre for Internet &amp; Website ServicesHostelsUniversity HospitalFitness CentreGuest HousesAmenitiesLinks »Certificate VerificationEmployee LoginHerbal GardenPensioner LoginSkill DevelopmentAcademic CalendarProspectusAnnual ReportsAudit ReportsEvents RecruitmentRTIPhoto GalleryFinancial DataFormsEnquiry Numbers








    
  ')]</value>
      <webElementGuid>51b2b9f3-3e41-484b-9a97-561fc9dab626</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
