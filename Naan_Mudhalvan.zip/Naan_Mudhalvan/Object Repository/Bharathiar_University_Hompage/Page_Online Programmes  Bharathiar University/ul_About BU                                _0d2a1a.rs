<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_About BU                                _0d2a1a</name>
   <tag></tag>
   <elementGuidId>ce7167f3-23c5-44dd-a1df-736781ecf6aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.gva_menu</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;About BU NIRF Online Payment UG &amp; PG Admissions 2024-25 Online Courses IQAC CUIC&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>9a7c3241-3979-44fc-a26b-92d4cdf685e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>gva_menu</value>
      <webElementGuid>a7fb5400-48ab-4c93-b3a1-35b637c9aeee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
        About BU
        
      
    
            
        NIRF
        
      
    
            
        Online Payment
        
      
    
            
        UG &amp; PG Admissions 2024-25
        
      
    
            
        Online Courses
        
      
    
            
        IQAC
        
      
    
            
        CUIC Courses
        
      
    
            
        Syllabus
        
      
        </value>
      <webElementGuid>ff9f1063-fd49-49a1-a9f0-091f298da4be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header-one&quot;)/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main-inner p-relative&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-7 col-sm-7 col-xs-7 content-inner&quot;]/div[@class=&quot;topbar-content&quot;]/nav[@class=&quot;top-rightmenu block block-menu navigation menu--about-bu&quot;]/div[@class=&quot;block-content&quot;]/dd[1]/ul[@class=&quot;gva_menu&quot;]</value>
      <webElementGuid>267c10e5-f63f-49c4-86cf-cfc4210b31a6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul</value>
      <webElementGuid>804ba4ce-2b08-4259-aad6-2346d41c1185</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About BU'])[1]/following::ul[1]</value>
      <webElementGuid>8a8c626c-3c57-46d1-b6f8-896ff0d7f2aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Translate'])[2]/following::ul[1]</value>
      <webElementGuid>5b93d558-c3dc-408f-9e83-568bb3547d18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd/ul</value>
      <webElementGuid>e9dc144f-a0b2-4f25-adf1-ecce523c6e82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
        
            
        About BU
        
      
    
            
        NIRF
        
      
    
            
        Online Payment
        
      
    
            
        UG &amp; PG Admissions 2024-25
        
      
    
            
        Online Courses
        
      
    
            
        IQAC
        
      
    
            
        CUIC Courses
        
      
    
            
        Syllabus
        
      
        ' or . = '
        
            
        About BU
        
      
    
            
        NIRF
        
      
    
            
        Online Payment
        
      
    
            
        UG &amp; PG Admissions 2024-25
        
      
    
            
        Online Courses
        
      
    
            
        IQAC
        
      
    
            
        CUIC Courses
        
      
    
            
        Syllabus
        
      
        ')]</value>
      <webElementGuid>0ee70dbf-9843-4a8e-adae-9de6685ecab1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
