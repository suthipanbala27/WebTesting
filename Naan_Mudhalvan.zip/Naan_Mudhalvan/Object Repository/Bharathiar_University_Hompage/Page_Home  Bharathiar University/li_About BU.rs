<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_About BU</name>
   <tag></tag>
   <elementGuidId>20153b7e-e544-428b-8c02-4d0051bb6918</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header']/div/div/div/div[2]/div/nav/div/dd/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.menu-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#header li >> internal:has-text=&quot;About BU&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>53943c42-680c-4b2e-b275-f9e1bcd3fbde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menu-item</value>
      <webElementGuid>374b839f-65b7-4d59-afb6-4c9e25e4f46b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        About BU
        
      </value>
      <webElementGuid>def09e19-e9f5-486f-a35b-679f7da2f5a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header&quot;)/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main-inner p-relative&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-7 col-sm-7 col-xs-7 content-inner&quot;]/div[@class=&quot;topbar-content&quot;]/nav[@class=&quot;top-rightmenu block block-menu navigation menu--about-bu&quot;]/div[@class=&quot;block-content&quot;]/dd[1]/ul[@class=&quot;gva_menu&quot;]/li[@class=&quot;menu-item&quot;]</value>
      <webElementGuid>f3c31e6e-676b-4f90-8657-09f9a021511b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header']/div/div/div/div[2]/div/nav/div/dd/ul/li</value>
      <webElementGuid>4219d4bc-14e1-4267-b930-b46481a64ec8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About BU'])[1]/following::li[1]</value>
      <webElementGuid>bb282240-11b8-430e-8ee2-5307dc4562bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Translate'])[2]/following::li[1]</value>
      <webElementGuid>e7660d95-51c2-41d9-acd3-a410dcc4e256</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[1]/preceding::li[1]</value>
      <webElementGuid>4853894c-9694-42b6-ac1b-56ca2a278d7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd/ul/li</value>
      <webElementGuid>0ccc9a10-4b6f-4740-b144-091d8511a3c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '
        About BU
        
      ' or . = '
        About BU
        
      ')]</value>
      <webElementGuid>1396df16-0260-4bec-8306-410261f23188</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
