<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_About BU</name>
   <tag></tag>
   <elementGuidId>4bcaa13d-60b0-44b0-9fee-b16ac319810a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header']/div/div/div/div[2]/div/nav/div/dd/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.menu-item > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;About BU&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ba03518d-c975-4279-980b-94237618aff0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/273/about-bu</value>
      <webElementGuid>0c3561ba-f7d1-4c3d-8d73-f03b21c072ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-drupal-link-system-path</name>
      <type>Main</type>
      <value>node/2787</value>
      <webElementGuid>307cc827-6f9e-4756-87a2-55c31cfce066</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>About BU</value>
      <webElementGuid>bfb2031e-9985-4127-82e5-127d9c798725</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header&quot;)/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main-inner p-relative&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-7 col-sm-7 col-xs-7 content-inner&quot;]/div[@class=&quot;topbar-content&quot;]/nav[@class=&quot;top-rightmenu block block-menu navigation menu--about-bu&quot;]/div[@class=&quot;block-content&quot;]/dd[1]/ul[@class=&quot;gva_menu&quot;]/li[@class=&quot;menu-item&quot;]/a[1]</value>
      <webElementGuid>14460ef5-36df-44b7-84df-4c695b382bba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header']/div/div/div/div[2]/div/nav/div/dd/ul/li/a</value>
      <webElementGuid>7c7b6459-e2df-428c-a3a1-4e8e75d96d38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'About BU')]</value>
      <webElementGuid>647a5931-291b-40d8-b14c-d1269518a6f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About BU'])[1]/following::a[1]</value>
      <webElementGuid>7918b466-6b92-47cd-87f2-82d9e13bc85c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Translate'])[2]/following::a[1]</value>
      <webElementGuid>328c8fc8-2a1f-4d5c-8595-20aedc885356</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[1]/preceding::a[1]</value>
      <webElementGuid>62b6e419-e0cc-4361-9b92-1f494757b974</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Payment'])[1]/preceding::a[2]</value>
      <webElementGuid>d01c999b-1ed2-4c3f-912e-e3abb4c36d84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/273/about-bu')]</value>
      <webElementGuid>c8f949df-d096-451a-88af-174d78658847</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd/ul/li/a</value>
      <webElementGuid>acf4d3aa-96b6-4e91-ac1e-40b3a317bbe2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/273/about-bu' and (text() = 'About BU' or . = 'About BU')]</value>
      <webElementGuid>56c1bda8-f13c-4ff5-8e01-5b037da6934d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
