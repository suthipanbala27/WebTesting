<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Online Courses</name>
   <tag></tag>
   <elementGuidId>4554777f-f2d8-42d7-850d-a89f97c28b25</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Online Courses&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>532e9aec-98f9-488b-8a6b-124587525d57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://b-u.ac.in/146/online-programmes</value>
      <webElementGuid>7750e51d-a5e9-4c6a-95f3-251316a703ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Online Courses</value>
      <webElementGuid>c5338cb7-a28d-4985-8565-c41991f51da7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header-one&quot;)/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main-inner p-relative&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-7 col-sm-7 col-xs-7 content-inner&quot;]/div[@class=&quot;topbar-content&quot;]/nav[@class=&quot;top-rightmenu block block-menu navigation menu--about-bu&quot;]/div[@class=&quot;block-content&quot;]/dd[1]/ul[@class=&quot;gva_menu&quot;]/li[@class=&quot;menu-item&quot;]/a[1]</value>
      <webElementGuid>5f951288-7b3e-4a03-a089-48218cbd04f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul/li[5]/a</value>
      <webElementGuid>2523449e-6213-41b7-b4ed-fc79b971b4f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Online Courses')]</value>
      <webElementGuid>344086b3-70c5-42d4-9e3e-543f3d1ea31b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG &amp; PG Admissions 2024-25'])[1]/following::a[1]</value>
      <webElementGuid>c5d9975e-b1d1-4957-b937-ec236ade7980</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Payment'])[1]/following::a[2]</value>
      <webElementGuid>12f0bb20-3cd5-4f73-9896-b4c40fcfa8ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC'])[1]/preceding::a[1]</value>
      <webElementGuid>bbc3dbb7-224f-4c61-a89b-4735400c4678</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CUIC Courses'])[1]/preceding::a[2]</value>
      <webElementGuid>3fd1e8b8-411f-4dfa-9885-03de63c6e0ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Online Courses']/parent::*</value>
      <webElementGuid>20b7292d-1638-44f2-a212-4c3f47ed77c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://b-u.ac.in/146/online-programmes')]</value>
      <webElementGuid>1fe4b2fb-d28c-4aff-b124-6b0aec0d056f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a</value>
      <webElementGuid>9be9e70d-e490-4580-b95e-98e7bfd9e055</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://b-u.ac.in/146/online-programmes' and (text() = 'Online Courses' or . = 'Online Courses')]</value>
      <webElementGuid>322a5762-2d05-4c64-acb0-eab81bbdad65</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
