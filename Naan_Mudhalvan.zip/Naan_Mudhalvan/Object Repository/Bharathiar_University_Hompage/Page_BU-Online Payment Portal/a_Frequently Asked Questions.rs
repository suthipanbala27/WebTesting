<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Frequently Asked Questions</name>
   <tag></tag>
   <elementGuidId>fd485510-700a-4988-8fe8-1fe1e5110d5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Frequently Asked Questions')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Frequently Asked Questions&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>efccecb9-73ae-4083-9b42-4b675f542ae6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#fqc</value>
      <webElementGuid>763f4c25-e943-4f3d-82d9-3e61dddfcf12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Frequently Asked Questions</value>
      <webElementGuid>403f39af-14e5-4f4d-b0ee-e20830df2348</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[1]/nav[@class=&quot;navbar&quot;]/ul[@class=&quot;all-links&quot;]/li[4]/a[1]</value>
      <webElementGuid>90ad2853-9b5f-4c9a-9702-57c32b112552</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Frequently Asked Questions')]</value>
      <webElementGuid>70f1b337-7af2-45cc-ab7d-745f17c4d254</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancellation / Refund Policy'])[1]/following::a[1]</value>
      <webElementGuid>62aa76f1-aa02-4bef-83d1-1de366084eed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacy Policy'])[1]/following::a[2]</value>
      <webElementGuid>f5fe90f6-94da-4a39-8393-a91b19270d15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/preceding::a[1]</value>
      <webElementGuid>f8cbd21a-8e49-4709-a668-6fe06a7442ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Payment/Service Portal'])[1]/preceding::a[2]</value>
      <webElementGuid>c086f18d-ef67-4097-ad13-ce48cac683bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Frequently Asked Questions']/parent::*</value>
      <webElementGuid>6f358efe-d413-402d-bdad-5f83af5c62e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#fqc')]</value>
      <webElementGuid>d43eace8-0849-4c84-a647-30bda1f98d41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/a</value>
      <webElementGuid>0ed94c32-3c8c-4165-9443-2d3cb0c4530b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#fqc' and (text() = 'Frequently Asked Questions' or . = 'Frequently Asked Questions')]</value>
      <webElementGuid>482f4d46-04f8-4a43-873a-7f45eae8f213</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
