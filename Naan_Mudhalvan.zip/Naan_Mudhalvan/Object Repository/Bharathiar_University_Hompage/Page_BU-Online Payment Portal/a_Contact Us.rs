<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Contact Us</name>
   <tag></tag>
   <elementGuidId>972fe416-ca32-4a69-995b-ab23c31f9eaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Contact Us')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(5) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Contact Us&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6c094ec6-0997-42ad-8108-7e998bd467cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#contact</value>
      <webElementGuid>374be07d-97ca-4a80-b903-dbc4ba989894</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Contact Us</value>
      <webElementGuid>20950649-98ef-4426-9a45-39e80a996674</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/header[1]/nav[@class=&quot;navbar&quot;]/ul[@class=&quot;all-links&quot;]/li[5]/a[1]</value>
      <webElementGuid>7cb0d5cd-d7b9-4f3c-b3cf-c35c409861be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Contact Us')]</value>
      <webElementGuid>cfd1cbed-2fda-43fc-86ef-352ec395c157</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Frequently Asked Questions'])[1]/following::a[1]</value>
      <webElementGuid>5c1420e2-3301-4fc6-93f9-eaeb221ca357</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancellation / Refund Policy'])[1]/following::a[2]</value>
      <webElementGuid>679a2e2a-75f2-4fc5-abbc-68558b7357a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Payment/Service Portal'])[1]/preceding::a[1]</value>
      <webElementGuid>b23e5e01-3e9a-4243-a7d8-d87cdf3d7d14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Contact Us']/parent::*</value>
      <webElementGuid>9d78077f-174b-43b1-8821-91c9857a6b76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#contact')]</value>
      <webElementGuid>1ea90d30-35af-42ac-89ec-8839f5ec65f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a</value>
      <webElementGuid>83ee4792-5267-481a-97ea-6cc92dc564dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#contact' and (text() = 'Contact Us' or . = 'Contact Us')]</value>
      <webElementGuid>9bbc871e-17e9-4ec3-b2d3-14e7303b66a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
