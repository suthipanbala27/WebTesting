<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_blink   animation 2s linear infinite co_387dcd</name>
   <tag></tag>
   <elementGuidId>867bef28-1d60-4a79-b63b-06fa5c36fc45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='bg']/div/header/div/div/div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container.clearfix</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;About Us Our History Vision &amp; Mission Core Values Organogram Strategic Plan with&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b909aaae-ee4e-41d9-aacf-34b2e5b6fa46</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container clearfix</value>
      <webElementGuid>299f2b2e-5db8-440e-8786-fb954a457808</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>			   
		
		
		
			
			
								
		
		

blink {
  animation: 2s linear infinite condemned_blink_effect;
}


    	
		
			About Us
			
				Our History
				Vision &amp; Mission
				Core Values
				Organogram
				Strategic Plan with Road Map
				
				Annual Budget
				History and Evolution of College of Engineering (CEG), AU
				Policies
				
				
			
		
		VC's Desk
			
				VC Profile	
				
				VC Photo Gallery
				VC Video Gallery
			
		
		 Administration
			
				 Administrators
					
						Syndicate
							
								Syndicate Members
								267th Syndicate Minutes	
								266th Syndicate Minutes
								265th Syndicate Minutes
								264th Syndicate Minutes	
								263rd Syndicate Minutes
								Annual Budget
							
							
						University Administration
						Deans (University Departments)
						
						Deans of Anna University Managed Affiliated Institutions
						Chairpersons
						Directors
						Head of the Departments
						Officers
					
				
				 Administrative Centres
					
						AU Sports Board
						AU-TVS Centre for Quality Management
						Atal Incubation Centre - AU Incubation Foundation
						Centre for Academic Courses
						Centre for Admissions
						Centre for Affiliation of Institutions
						Centre for Blended Learning and Human Empowerment						
						Centre for Distance Education
						Centre for e-Governance
						Centre for Entrance Examinations
						Centre for Entrepreneurship Development
						
						Centre for Faculty and Professional Development
						
						Centre for Human Settlements
						Centre for International Relations
						Centre for Intellectual Property Rights
						Centre for Sponsored Research and Consultancy
						Centre for University Industry Collaboration
						Centre for Empowerment of Women
						Estate Office
						Health Centre
						
						Logistic Centre
						Office of the Controller of Examinations
						Student Affairs
						SC/ST Cell
						Recruitment Cell
						University Library	
					
													
			
			
		 Departments
			
				CEG Campus
					
						Civil Engineering
						Chemistry
						
						Computer Science and Engineering
						Electrical and Electronics Engineering
						Electronics and Communication Engineering
						English
						Geology
						Information Science and Technology
						Industrial Engineering
						Mathematics
						Manufacturing Engineering
						
						Management Studies	
						Mechanical Engineering 
						Media Sciences 
						Medical Physics
						Mining Engineering
						Physics
						Printing and Packaging Technology
						 
						
							
					
				
				MIT Campus
					
						Aerospace Engineering 
						Automobile Engineering
						Applied Science and Humanities
						Computer Technology
						Electronics Engineering
						Information Technology
						Instrumentation Engineering						
						Production Technology 
						Rubber and Plastic Technology
					
				
				 ACT Campus
					
						Applied Science Technology	
                        Bio-Technology	
						
						Ceramic Technology
						
						Chemical Engineering
						Leather Technology
						Textile Technology 
					
				
				 SAP Campus
					
						Architecture
						Planning
					
				
				
					
						Syllabus &amp; Curriculum
						
						Centre for Distance Education
					
				
			
		
		 Research
			
				Academic Research (Ph.D/MS)
				Sponsored Research / Consultancy
				 Research Centres	
					
						AU-FRG Institute for CAD/CAM
						AU-KBC Research Centre for Emerging Technologies
						AU-RU Urban Energy Centre
						Building Technology Centre
						Centre for Aerospace Research
						Centre for Applied Research in Indic Technologies
						Centre for Biotechnology
						Centre for Climate Change and Disaster Management
						Centre for Development of Tamil in Engg.&amp; Technology
						Centre for Energy Storage Technologies
						Centre for Environmental Studies
						Centre for Food Technology										
															
						Centre for Medical Electronics
						Centre for Nano Science and Technology
						Centre for Water Resources
						Crystal Growth Centre
						Educational Multimedia Research Centre
						Institute for Energy Studies
						Institute for Ocean Management
						Institute of Remote Sensing
						NHHID - National Hub for Healthcare Instrumentation Development
						Ramanujan Computing Centre
						Centre for Artificial Intelligence &amp; Data Science Research &amp; Applications (CAInDRA)	
						Centre for Immersive Technologies	
						Centre for Multi-Disciplinary System Research (CMDSR)
						Centre for Survey Training and Research (C-STAR)
						Centre for Materials Informatics (C-mAIn)
						Centre for Wireless System Design (C-WiSD)
						Institute of Catalysis and Petroleum Technology
						Centre for Science and Technology for Advanced Heritage Studies (CESTAHS)
						Bost Einstein Science and Technology (BEST) Centre for Fundmental Research
						Centre for Composite Materials (CCM)
						Centre for Technology in Traditional Medicine
					
				
				Research Facilities
					
						NHHID - National Hub for Healthcare Instrumentation Development
						Crystal Growth Centre
						Institute of Remote Sensing											
					
				
													
			
		
		Innovations
			
				Centre for Entrepreneurship Development
				Centre for Intellectual Property Rights
				
				ANIHESS
				NHHID - National Hub for Healthcare Instrumentation Development	
				Atal Incubation Centre - Anna Inncubation Foundation		
				Technology Enabling Centre
				E-YUVA Centre (University Innovation Cluster)									
			
		
		Examinations
			
				University Campus (ACoE)	
				Affiliated Colleges (CoE)																	
			
		
		
		Curriculum
		Admissions
			
				Centre for Admissions	
				International Admissions (UG/PG)																	
			
		
		e-Learning
		
			Infosys-SpringBoard	
		
				
									
		
		
						
					
					
				
		
			
        
		

        

		
		
			
			
			
			
			
			
			
			
			
			
							
			
			
						
			
			
			
			
			
			
			QS World University Rankings 2025 - 383rd in the world and 10th among 46 Indian Institutions       
			
			Kind attention to Distinguished Alumni of CEG, ACT, MIT &amp; SAP
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
									

			

			
				
			
			
			 
			
			
			
			
			
			
			
			 
			
			

						
			
			
					
			
			
			
			
			
			
						
			
			

			

			
			
			
			
			
			
			
			
			
			
			
			
						
				

        
		
		
	</value>
      <webElementGuid>94ef27d8-4bbc-47fb-8065-59688a05fdd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bg&quot;)/div[@class=&quot;page-wraper&quot;]/header[@class=&quot;site-header mo-left header&quot;]/div[@class=&quot;sticky-header main-bar-wraper navbar-expand-lg is-fixed&quot;]/div[@class=&quot;main-bar clearfix&quot;]/div[@class=&quot;container clearfix&quot;]</value>
      <webElementGuid>58942d99-b03f-4040-b412-76fcb1dfbdbe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='bg']/div/header/div/div/div[3]</value>
      <webElementGuid>23a09963-ab0c-4930-b7bb-94a7225ceefa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NRI/FN/CIWGC(PG Category)'])[1]/following::div[1]</value>
      <webElementGuid>0f72e054-8291-4c08-ad4c-0faba89d673c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG Admission 2024-25'])[1]/following::div[1]</value>
      <webElementGuid>17eb3287-b490-4f39-95fc-ba85a2479185</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[3]</value>
      <webElementGuid>dc8d2e18-3356-44a8-aa82-0b4c130016a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;			   
		
		
		
			
			
								
		
		

blink {
  animation: 2s linear infinite condemned_blink_effect;
}


    	
		
			About Us
			
				Our History
				Vision &amp; Mission
				Core Values
				Organogram
				Strategic Plan with Road Map
				
				Annual Budget
				History and Evolution of College of Engineering (CEG), AU
				Policies
				
				
			
		
		VC&quot; , &quot;'&quot; , &quot;s Desk
			
				VC Profile	
				
				VC Photo Gallery
				VC Video Gallery
			
		
		 Administration
			
				 Administrators
					
						Syndicate
							
								Syndicate Members
								267th Syndicate Minutes	
								266th Syndicate Minutes
								265th Syndicate Minutes
								264th Syndicate Minutes	
								263rd Syndicate Minutes
								Annual Budget
							
							
						University Administration
						Deans (University Departments)
						
						Deans of Anna University Managed Affiliated Institutions
						Chairpersons
						Directors
						Head of the Departments
						Officers
					
				
				 Administrative Centres
					
						AU Sports Board
						AU-TVS Centre for Quality Management
						Atal Incubation Centre - AU Incubation Foundation
						Centre for Academic Courses
						Centre for Admissions
						Centre for Affiliation of Institutions
						Centre for Blended Learning and Human Empowerment						
						Centre for Distance Education
						Centre for e-Governance
						Centre for Entrance Examinations
						Centre for Entrepreneurship Development
						
						Centre for Faculty and Professional Development
						
						Centre for Human Settlements
						Centre for International Relations
						Centre for Intellectual Property Rights
						Centre for Sponsored Research and Consultancy
						Centre for University Industry Collaboration
						Centre for Empowerment of Women
						Estate Office
						Health Centre
						
						Logistic Centre
						Office of the Controller of Examinations
						Student Affairs
						SC/ST Cell
						Recruitment Cell
						University Library	
					
													
			
			
		 Departments
			
				CEG Campus
					
						Civil Engineering
						Chemistry
						
						Computer Science and Engineering
						Electrical and Electronics Engineering
						Electronics and Communication Engineering
						English
						Geology
						Information Science and Technology
						Industrial Engineering
						Mathematics
						Manufacturing Engineering
						
						Management Studies	
						Mechanical Engineering 
						Media Sciences 
						Medical Physics
						Mining Engineering
						Physics
						Printing and Packaging Technology
						 
						
							
					
				
				MIT Campus
					
						Aerospace Engineering 
						Automobile Engineering
						Applied Science and Humanities
						Computer Technology
						Electronics Engineering
						Information Technology
						Instrumentation Engineering						
						Production Technology 
						Rubber and Plastic Technology
					
				
				 ACT Campus
					
						Applied Science Technology	
                        Bio-Technology	
						
						Ceramic Technology
						
						Chemical Engineering
						Leather Technology
						Textile Technology 
					
				
				 SAP Campus
					
						Architecture
						Planning
					
				
				
					
						Syllabus &amp; Curriculum
						
						Centre for Distance Education
					
				
			
		
		 Research
			
				Academic Research (Ph.D/MS)
				Sponsored Research / Consultancy
				 Research Centres	
					
						AU-FRG Institute for CAD/CAM
						AU-KBC Research Centre for Emerging Technologies
						AU-RU Urban Energy Centre
						Building Technology Centre
						Centre for Aerospace Research
						Centre for Applied Research in Indic Technologies
						Centre for Biotechnology
						Centre for Climate Change and Disaster Management
						Centre for Development of Tamil in Engg.&amp; Technology
						Centre for Energy Storage Technologies
						Centre for Environmental Studies
						Centre for Food Technology										
															
						Centre for Medical Electronics
						Centre for Nano Science and Technology
						Centre for Water Resources
						Crystal Growth Centre
						Educational Multimedia Research Centre
						Institute for Energy Studies
						Institute for Ocean Management
						Institute of Remote Sensing
						NHHID - National Hub for Healthcare Instrumentation Development
						Ramanujan Computing Centre
						Centre for Artificial Intelligence &amp; Data Science Research &amp; Applications (CAInDRA)	
						Centre for Immersive Technologies	
						Centre for Multi-Disciplinary System Research (CMDSR)
						Centre for Survey Training and Research (C-STAR)
						Centre for Materials Informatics (C-mAIn)
						Centre for Wireless System Design (C-WiSD)
						Institute of Catalysis and Petroleum Technology
						Centre for Science and Technology for Advanced Heritage Studies (CESTAHS)
						Bost Einstein Science and Technology (BEST) Centre for Fundmental Research
						Centre for Composite Materials (CCM)
						Centre for Technology in Traditional Medicine
					
				
				Research Facilities
					
						NHHID - National Hub for Healthcare Instrumentation Development
						Crystal Growth Centre
						Institute of Remote Sensing											
					
				
													
			
		
		Innovations
			
				Centre for Entrepreneurship Development
				Centre for Intellectual Property Rights
				
				ANIHESS
				NHHID - National Hub for Healthcare Instrumentation Development	
				Atal Incubation Centre - Anna Inncubation Foundation		
				Technology Enabling Centre
				E-YUVA Centre (University Innovation Cluster)									
			
		
		Examinations
			
				University Campus (ACoE)	
				Affiliated Colleges (CoE)																	
			
		
		
		Curriculum
		Admissions
			
				Centre for Admissions	
				International Admissions (UG/PG)																	
			
		
		e-Learning
		
			Infosys-SpringBoard	
		
				
									
		
		
						
					
					
				
		
			
        
		

        

		
		
			
			
			
			
			
			
			
			
			
			
							
			
			
						
			
			
			
			
			
			
			QS World University Rankings 2025 - 383rd in the world and 10th among 46 Indian Institutions       
			
			Kind attention to Distinguished Alumni of CEG, ACT, MIT &amp; SAP
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
									

			

			
				
			
			
			 
			
			
			
			
			
			
			
			 
			
			

						
			
			
					
			
			
			
			
			
			
						
			
			

			

			
			
			
			
			
			
			
			
			
			
			
			
						
				

        
		
		
	&quot;) or . = concat(&quot;			   
		
		
		
			
			
								
		
		

blink {
  animation: 2s linear infinite condemned_blink_effect;
}


    	
		
			About Us
			
				Our History
				Vision &amp; Mission
				Core Values
				Organogram
				Strategic Plan with Road Map
				
				Annual Budget
				History and Evolution of College of Engineering (CEG), AU
				Policies
				
				
			
		
		VC&quot; , &quot;'&quot; , &quot;s Desk
			
				VC Profile	
				
				VC Photo Gallery
				VC Video Gallery
			
		
		 Administration
			
				 Administrators
					
						Syndicate
							
								Syndicate Members
								267th Syndicate Minutes	
								266th Syndicate Minutes
								265th Syndicate Minutes
								264th Syndicate Minutes	
								263rd Syndicate Minutes
								Annual Budget
							
							
						University Administration
						Deans (University Departments)
						
						Deans of Anna University Managed Affiliated Institutions
						Chairpersons
						Directors
						Head of the Departments
						Officers
					
				
				 Administrative Centres
					
						AU Sports Board
						AU-TVS Centre for Quality Management
						Atal Incubation Centre - AU Incubation Foundation
						Centre for Academic Courses
						Centre for Admissions
						Centre for Affiliation of Institutions
						Centre for Blended Learning and Human Empowerment						
						Centre for Distance Education
						Centre for e-Governance
						Centre for Entrance Examinations
						Centre for Entrepreneurship Development
						
						Centre for Faculty and Professional Development
						
						Centre for Human Settlements
						Centre for International Relations
						Centre for Intellectual Property Rights
						Centre for Sponsored Research and Consultancy
						Centre for University Industry Collaboration
						Centre for Empowerment of Women
						Estate Office
						Health Centre
						
						Logistic Centre
						Office of the Controller of Examinations
						Student Affairs
						SC/ST Cell
						Recruitment Cell
						University Library	
					
													
			
			
		 Departments
			
				CEG Campus
					
						Civil Engineering
						Chemistry
						
						Computer Science and Engineering
						Electrical and Electronics Engineering
						Electronics and Communication Engineering
						English
						Geology
						Information Science and Technology
						Industrial Engineering
						Mathematics
						Manufacturing Engineering
						
						Management Studies	
						Mechanical Engineering 
						Media Sciences 
						Medical Physics
						Mining Engineering
						Physics
						Printing and Packaging Technology
						 
						
							
					
				
				MIT Campus
					
						Aerospace Engineering 
						Automobile Engineering
						Applied Science and Humanities
						Computer Technology
						Electronics Engineering
						Information Technology
						Instrumentation Engineering						
						Production Technology 
						Rubber and Plastic Technology
					
				
				 ACT Campus
					
						Applied Science Technology	
                        Bio-Technology	
						
						Ceramic Technology
						
						Chemical Engineering
						Leather Technology
						Textile Technology 
					
				
				 SAP Campus
					
						Architecture
						Planning
					
				
				
					
						Syllabus &amp; Curriculum
						
						Centre for Distance Education
					
				
			
		
		 Research
			
				Academic Research (Ph.D/MS)
				Sponsored Research / Consultancy
				 Research Centres	
					
						AU-FRG Institute for CAD/CAM
						AU-KBC Research Centre for Emerging Technologies
						AU-RU Urban Energy Centre
						Building Technology Centre
						Centre for Aerospace Research
						Centre for Applied Research in Indic Technologies
						Centre for Biotechnology
						Centre for Climate Change and Disaster Management
						Centre for Development of Tamil in Engg.&amp; Technology
						Centre for Energy Storage Technologies
						Centre for Environmental Studies
						Centre for Food Technology										
															
						Centre for Medical Electronics
						Centre for Nano Science and Technology
						Centre for Water Resources
						Crystal Growth Centre
						Educational Multimedia Research Centre
						Institute for Energy Studies
						Institute for Ocean Management
						Institute of Remote Sensing
						NHHID - National Hub for Healthcare Instrumentation Development
						Ramanujan Computing Centre
						Centre for Artificial Intelligence &amp; Data Science Research &amp; Applications (CAInDRA)	
						Centre for Immersive Technologies	
						Centre for Multi-Disciplinary System Research (CMDSR)
						Centre for Survey Training and Research (C-STAR)
						Centre for Materials Informatics (C-mAIn)
						Centre for Wireless System Design (C-WiSD)
						Institute of Catalysis and Petroleum Technology
						Centre for Science and Technology for Advanced Heritage Studies (CESTAHS)
						Bost Einstein Science and Technology (BEST) Centre for Fundmental Research
						Centre for Composite Materials (CCM)
						Centre for Technology in Traditional Medicine
					
				
				Research Facilities
					
						NHHID - National Hub for Healthcare Instrumentation Development
						Crystal Growth Centre
						Institute of Remote Sensing											
					
				
													
			
		
		Innovations
			
				Centre for Entrepreneurship Development
				Centre for Intellectual Property Rights
				
				ANIHESS
				NHHID - National Hub for Healthcare Instrumentation Development	
				Atal Incubation Centre - Anna Inncubation Foundation		
				Technology Enabling Centre
				E-YUVA Centre (University Innovation Cluster)									
			
		
		Examinations
			
				University Campus (ACoE)	
				Affiliated Colleges (CoE)																	
			
		
		
		Curriculum
		Admissions
			
				Centre for Admissions	
				International Admissions (UG/PG)																	
			
		
		e-Learning
		
			Infosys-SpringBoard	
		
				
									
		
		
						
					
					
				
		
			
        
		

        

		
		
			
			
			
			
			
			
			
			
			
			
							
			
			
						
			
			
			
			
			
			
			QS World University Rankings 2025 - 383rd in the world and 10th among 46 Indian Institutions       
			
			Kind attention to Distinguished Alumni of CEG, ACT, MIT &amp; SAP
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
						
			
			
			
			
			
			
			
			
			
									

			

			
				
			
			
			 
			
			
			
			
			
			
			
			 
			
			

						
			
			
					
			
			
			
			
			
			
						
			
			

			

			
			
			
			
			
			
			
			
			
			
			
			
						
				

        
		
		
	&quot;))]</value>
      <webElementGuid>9205476d-824f-47df-a9d4-d8205bbfec23</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
