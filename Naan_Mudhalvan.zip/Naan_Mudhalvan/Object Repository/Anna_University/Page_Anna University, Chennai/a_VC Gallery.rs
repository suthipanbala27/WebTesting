<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_VC Gallery</name>
   <tag></tag>
   <elementGuidId>2cbfa382-d3b1-4cbd-9cc8-b86674f7f248</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='bg']/header/div/nav/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(2) > a.ripple</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; VC Gallery&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b11a6c68-444b-483d-91be-367c398b56a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.annauniv.edu/vcgallery.php</value>
      <webElementGuid>98b36280-f7d3-465b-b477-89c31f24e050</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ripple</value>
      <webElementGuid>d838f451-3d42-47c6-ba54-ec729090980f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>University Events</value>
      <webElementGuid>40f38a8b-be2e-4efd-91d5-6af078abddde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>24ea3914-57d6-4028-9797-7a1218992a3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						 VC Gallery
					</value>
      <webElementGuid>cf873d83-b526-44da-8f06-fd1d401ba1e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bg&quot;)/header[1]/div[@class=&quot;page-content bg-white&quot;]/nav[@class=&quot;floating-menu&quot;]/ul[@class=&quot;main-menu&quot;]/li[2]/a[@class=&quot;ripple&quot;]</value>
      <webElementGuid>a5bcc2d9-3641-4ac4-8509-998545b360f9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='bg']/header/div/nav/ul/li[2]/a</value>
      <webElementGuid>8239e42a-3bc3-499f-b3c7-e22b33aee7e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kind attention to Distinguished Alumni of CEG, ACT, MIT &amp; SAP'])[1]/following::a[2]</value>
      <webElementGuid>2623352d-4d84-485e-b291-09b66ef371ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='VC Gallery']/parent::*</value>
      <webElementGuid>8208d69e-0cd1-4584-b650-9e166bedfd89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.annauniv.edu/vcgallery.php')])[2]</value>
      <webElementGuid>229e3df4-61f6-4da1-9fcc-9b0724a1fd85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav/ul/li[2]/a</value>
      <webElementGuid>0f88f761-6fed-4eb5-907b-7c4762a2b129</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.annauniv.edu/vcgallery.php' and @title = 'University Events' and (text() = '
						 VC Gallery
					' or . = '
						 VC Gallery
					')]</value>
      <webElementGuid>eebe9f5b-e77a-4788-8094-395790aa1664</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
