<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Library                With a vast coll_40795b</name>
   <tag></tag>
   <elementGuidId>e4210b14-0074-4a3d-b161-8b05091f3e5e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='facilities']/div/div[2]/div[3]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Library With a vast collection of more than 1500 books, journals, multimedia res&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>be3d4dfe-952c-4c80-a41b-57de4120a7b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>details</value>
      <webElementGuid>91edf285-d06f-47b3-be0f-102b6b59a73e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Library
                With a vast collection of more than 1500 books, journals, multimedia resources, and serene study spaces, we provide an environment that fosters curiosity and intellectual growth.
              </value>
      <webElementGuid>2e254573-683e-423c-a5d5-d862ffde1619</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;facilities&quot;)/div[@class=&quot;container aos-init aos-animate&quot;]/div[@class=&quot;row gy-5&quot;]/div[@class=&quot;col-xl-4 col-md-6 aos-init aos-animate&quot;]/div[@class=&quot;facilities-item&quot;]/div[@class=&quot;details&quot;]</value>
      <webElementGuid>f47f1f57-cbfa-411b-9ff2-b22795b754e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='facilities']/div/div[2]/div[3]/div/div[2]</value>
      <webElementGuid>9ed1e9f4-e119-4bbc-aaa5-10d40b101101</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='High Performance Computing Lab'])[1]/following::div[4]</value>
      <webElementGuid>be48f841-4bf1-48f8-830b-3387dea4eb29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Distributed Computing Lab'])[1]/following::div[8]</value>
      <webElementGuid>6e71c9f2-41aa-4158-9829-f1640453c9fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Server'])[1]/preceding::div[2]</value>
      <webElementGuid>e5bdaa53-0f19-4fe0-a3a5-1d369d07b907</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]</value>
      <webElementGuid>9410c6d1-9ce1-4f0c-8dd7-687f4e69dba0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                Library
                With a vast collection of more than 1500 books, journals, multimedia resources, and serene study spaces, we provide an environment that fosters curiosity and intellectual growth.
              ' or . = '
                Library
                With a vast collection of more than 1500 books, journals, multimedia resources, and serene study spaces, we provide an environment that fosters curiosity and intellectual growth.
              ')]</value>
      <webElementGuid>39d0c310-4a32-444b-9e85-92d3fdc6b767</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
