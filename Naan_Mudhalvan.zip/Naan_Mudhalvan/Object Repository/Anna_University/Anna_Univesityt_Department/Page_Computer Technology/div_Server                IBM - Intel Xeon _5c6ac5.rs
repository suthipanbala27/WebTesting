<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Server                IBM - Intel Xeon _5c6ac5</name>
   <tag></tag>
   <elementGuidId>3b5a37b0-f068-4b05-9475-1dd5cb0548b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='facilities']/div/div[2]/div[4]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Server IBM - Intel Xeon Processor with 64 GB RAM - 3 Nos; 1 IBM 8TB SAN Storage&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6575964b-1932-4d90-b688-a67812884cf2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>details</value>
      <webElementGuid>a6be1321-22cf-46d5-8ed7-7d9faf2c371e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Server
                IBM - Intel Xeon Processor with 64 GB RAM - 3 Nos; 1 IBM 8TB SAN Storage
              </value>
      <webElementGuid>5d6a40fe-e623-44f7-b3c3-2ed76e55381b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;facilities&quot;)/div[@class=&quot;container aos-init aos-animate&quot;]/div[@class=&quot;row gy-5&quot;]/div[@class=&quot;col-xl-4 col-md-6 aos-init aos-animate&quot;]/div[@class=&quot;facilities-item&quot;]/div[@class=&quot;details&quot;]</value>
      <webElementGuid>a8bb4f38-4d3d-4efb-973a-35976ebde331</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='facilities']/div/div[2]/div[4]/div/div[2]</value>
      <webElementGuid>4ff04a0e-d3c9-41d4-b00e-0b71f1b44d51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Library'])[1]/following::div[4]</value>
      <webElementGuid>ed2ab76d-093c-481c-9f0f-7ca68cb6a694</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='High Performance Computing Lab'])[1]/following::div[8]</value>
      <webElementGuid>ec054919-a68c-4369-9dd6-193a722453a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Conference Hall'])[1]/preceding::div[2]</value>
      <webElementGuid>6accbbd1-40af-452e-b169-50a206894ea7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]</value>
      <webElementGuid>8ae1e8b2-4fdd-4562-bf9a-a8df3dfeb2a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                Server
                IBM - Intel Xeon Processor with 64 GB RAM - 3 Nos; 1 IBM 8TB SAN Storage
              ' or . = '
                Server
                IBM - Intel Xeon Processor with 64 GB RAM - 3 Nos; 1 IBM 8TB SAN Storage
              ')]</value>
      <webElementGuid>9a2ab9d6-cc9e-4171-b662-f7ca2fcc8a8b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
