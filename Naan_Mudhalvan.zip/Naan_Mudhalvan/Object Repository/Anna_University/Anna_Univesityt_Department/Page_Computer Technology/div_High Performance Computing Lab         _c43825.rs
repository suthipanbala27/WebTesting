<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_High Performance Computing Lab         _c43825</name>
   <tag></tag>
   <elementGuidId>f7a7292e-003b-4e11-96dc-cd6937a3a62d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='facilities']/div/div[2]/div[2]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;High Performance Computing Lab Desktops: Core i7/16GB - 80 Nos&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>861e3dac-c851-4549-9512-ed1b2067150c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>details</value>
      <webElementGuid>fec0e1fd-6f22-4473-aac0-ca769370793d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                High Performance Computing Lab
                Desktops: Core i7/16GB - 80 Nos
              </value>
      <webElementGuid>15136ca5-7a8a-4345-be28-c5659c8e5546</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;facilities&quot;)/div[@class=&quot;container aos-init aos-animate&quot;]/div[@class=&quot;row gy-5&quot;]/div[@class=&quot;col-xl-4 col-md-6 aos-init aos-animate&quot;]/div[@class=&quot;facilities-item&quot;]/div[@class=&quot;details&quot;]</value>
      <webElementGuid>5af92082-e180-496a-b7af-6e775b3278e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='facilities']/div/div[2]/div[2]/div/div[2]</value>
      <webElementGuid>0a72c050-edcd-4807-b2a1-e13dd65815d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Distributed Computing Lab'])[1]/following::div[4]</value>
      <webElementGuid>82c3ca4f-2036-4d50-a79e-8672faadc23b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Facilities'])[2]/following::div[9]</value>
      <webElementGuid>3759df92-4194-4c6b-b157-5fa82f0cbfd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Library'])[1]/preceding::div[2]</value>
      <webElementGuid>a8459ff1-fba6-4cb0-a7dc-6b6eabd43522</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]</value>
      <webElementGuid>1d0910ac-7fb6-4f6d-9ee2-4b8ea9d5413a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                High Performance Computing Lab
                Desktops: Core i7/16GB - 80 Nos
              ' or . = '
                High Performance Computing Lab
                Desktops: Core i7/16GB - 80 Nos
              ')]</value>
      <webElementGuid>32517fef-80aa-4175-960b-f176ec480a40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
