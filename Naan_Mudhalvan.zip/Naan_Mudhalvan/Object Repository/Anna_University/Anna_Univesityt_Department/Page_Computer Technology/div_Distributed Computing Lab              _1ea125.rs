<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Distributed Computing Lab              _1ea125</name>
   <tag></tag>
   <elementGuidId>7c6f89e3-ec60-4249-be0d-272b00642b5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='facilities']/div/div[2]/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.details</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Distributed Computing Lab Desktops Core i7/16GB - 82 Nos&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>12d11275-e9f4-4631-b83b-ecbb0edfc8fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>details</value>
      <webElementGuid>abc41433-24ae-4c5c-a3ea-05bee373d300</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Distributed Computing Lab
                Desktops Core i7/16GB - 82 Nos
              </value>
      <webElementGuid>bbdbc3db-b44f-49a5-a8c6-cbf2977ba17d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;facilities&quot;)/div[@class=&quot;container aos-init aos-animate&quot;]/div[@class=&quot;row gy-5&quot;]/div[@class=&quot;col-xl-4 col-md-6 aos-init aos-animate&quot;]/div[@class=&quot;facilities-item&quot;]/div[@class=&quot;details&quot;]</value>
      <webElementGuid>387eab75-e46a-4d8b-9063-d27e706cb0ac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='facilities']/div/div[2]/div/div/div[2]</value>
      <webElementGuid>3e570410-ccf8-48af-a649-90872f057262</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Facilities'])[2]/following::div[5]</value>
      <webElementGuid>5e123ee0-3083-4164-8b15-1db7b8774779</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/following::div[7]</value>
      <webElementGuid>19fe8c41-7e17-433a-9a6e-18b558ad82ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='High Performance Computing Lab'])[1]/preceding::div[2]</value>
      <webElementGuid>e9645d4c-5db9-4b37-8d97-4f54a89ae765</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]</value>
      <webElementGuid>b51eec83-ac31-4e30-9226-4a7f36e03c32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                Distributed Computing Lab
                Desktops Core i7/16GB - 82 Nos
              ' or . = '
                Distributed Computing Lab
                Desktops Core i7/16GB - 82 Nos
              ')]</value>
      <webElementGuid>e728dfe6-6b34-4fde-8bed-33a178229c36</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
